package com.ssikiss.phone4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 배치에 있던 Button을 찾아서.

        Button cal = findViewById(R.id.button1);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),CalActivity.class);
                startActivity(intent); //넘겨주는 것은 startActivity 임.
            }
        });


        //1. 배치에 있던 Button을 찾아서.

        Button login = findViewById(R.id.login);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent); //넘겨주는 것은 startActivity 임.
            }
        });



        //메인화면의 "로그인ok" 버튼을 눌렀을 경우 로그인ok 화면으로 전환하기
        //1. 배치에 있던 Button을 찾아서.
        Button ok = findViewById(R.id.ok);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),OkActivity.class);
                startActivity(intent); //넘겨주는 것은 startActivity 임.
            }
        });

        //메인화면의 "로그인not" 버튼을 눌렀을 경우 로그인not 화면으로 전환하기
        //1. 배치에 있던 Button을 찾아서.
        Button not = findViewById(R.id.not);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        not.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),NoyActivity.class); //Not->Noy 오타
                startActivity(intent); //넘겨주는 것은 startActivity 임.
            }
        });


    }
}
