package com.ssikiss.phone4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //진짜 id, pw를 설정한다.
        final String rid = "abcd";
        final String rpw = "1234";

        // 이전에 작성해둔 코딩을 복사해서 붙인 후 수정한다.
        //1. 배치에 있던 Button을 찾아서.
        Button login2 = findViewById(R.id.login2);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        login2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //EditText 로 num1, num2를 찾기만 함.
                EditText id2 = findViewById(R.id.id2);
                EditText pw = findViewById(R.id.pw);

                String id22 = id2.getText().toString(); //숫자를 가져오고 : getText, 문자로 처리해주세요. : toString
                String pw2 = pw.getText().toString(); //우선 프로그램에서는 먼저 스트링으로 가져와야 하므로 스트링으로 처리함.

                if(id22.equals(rid)&&pw2.equals(rpw)){
                    Intent intent = new Intent(getApplicationContext(),OkActivity.class); //조건이 맞으면 okactivity로 전환된다.
                    startActivity(intent);
                }
                else {                                                                     //조건이 안맞으면 noyactivity로 전환된다.
                    Intent intent = new Intent(getApplicationContext(),NoyActivity.class); //Not->Noy 오타
                    startActivity(intent);
                } //if(){} else(){} 를 직접 손으로 쳐준다.(자동완성 아님)

            }
        });









    }
}
