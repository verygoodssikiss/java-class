package com.ssikiss.phone4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);

        // 이전에 작성해둔 코딩을 복사해서 붙인 후 수정한다.
        //1. 배치에 있던 Button을 찾아서.

        Button plus = findViewById(R.id.plus);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //EditText 로 num1, num2를 찾기만 함.
               EditText num1 = findViewById(R.id.num1);
               EditText num2 = findViewById(R.id.num2);

               String n1 = num1.getText().toString(); //숫자를 가져오고 : getText, 문자로 처리해주세요. : toString
               String n2 = num2.getText().toString(); //우선 프로그램에서는 먼저 스트링으로 가져와야 하므로 스트링으로 처리함.

               //string으로 가져왔으므로 숫자로 인식하게 함.
                // 숫자로 처리하는 경우가 많으므로 원본을 가져다 쓴다. 문자열(String)->정수(Integer)
                // 부품의 이름이 Integer임.
                int i1 = Integer.parseInt(n1); //n1을 parse해서 숫자로 바꿀 수 있으면 숫자로 바꿔줘.
                int i2 = Integer.parseInt(n2);

                int total = i1 + i2;

                Toast.makeText(getApplicationContext(),"두수의 합은"+total+"입니다.",Toast.LENGTH_LONG).show();
                        //total은 int이므로 +"" (스트링)을 더해주면 스트링으로 인식된다.

                TextView result = findViewById(R.id.result);
                result.setText("두수의 합은"+total);



            }
        });


        //1. 배치에 있던 Button을 찾아서.

        Button minus = findViewById(R.id.minus);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //EditText 로 num1, num2를 찾기만 함.
                EditText num1 = findViewById(R.id.num1);
                EditText num2 = findViewById(R.id.num2);

                String n1 = num1.getText().toString(); //숫자를 가져오고 : getText, 문자로 처리해주세요. : toString
                String n2 = num2.getText().toString(); //우선 프로그램에서는 먼저 스트링으로 가져와야 하므로 스트링으로 처리함.

                //string으로 가져왔으므로 숫자로 인식하게 함.
                // 숫자로 처리하는 경우가 많으므로 원본을 가져다 쓴다. 문자열(String)->정수(Integer)
                // 부품의 이름이 Integer임.
                int i1 = Integer.parseInt(n1); //n1을 parse해서 숫자로 바꿀 수 있으면 숫자로 바꿔줘.
                int i2 = Integer.parseInt(n2);

                int total = i1 - i2;

                Toast.makeText(getApplicationContext(),"두수의 차는"+total+"입니다.",Toast.LENGTH_LONG).show();
                //total은 int이므로 +"" (스트링)을 더해주면 스트링으로 인식된다.

                TextView result = findViewById(R.id.result);
                result.setText("두수의 차는"+total);



            }
        });


        //메인화면으로 전환하기
        //1. 배치에 있던 Button을 찾아서.

        Button main = findViewById(R.id.main);

        //2. 버튼을 눌렀을 때, 액션처리 셋팅

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent); //넘겨주는 것은 startActivity 임.
            }
        });




    }
}
