package com.ssikiss.mybookmark2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("KB금융 초급과정");


        //birth
        Button birth = findViewById(R.id.birth);

        birth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"가족생일 화면으로 전환합니다",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),BirthActivity.class);
                startActivity(intent);
            }
        });

        //album
        Button album = findViewById(R.id.album);

        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"가족앨범 화면으로 전환합니다",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),AlbumActivity.class);
                startActivity(intent);
            }
        });

        //call
        Button call = findViewById(R.id.call);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"지인연락처 화면으로 전환합니다",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),CallActivity.class);
                startActivity(intent);
            }
        });

        //food
        Button food = findViewById(R.id.food);

        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"나의 맛집 화면으로 전환합니다",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),FoodActivity.class);
                startActivity(intent);
            }
        });






    }
}
