package com.ssikiss.phone02;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);

        //1. 레이아웃에 있는 View(뷰)를 선택
        final Button toast = findViewById(R.id.toast); //토스트라는 버튼을 인식하게 함.


        //2. button을 가지고 와서 액션 처리
        toast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"내가바로 토스트예요....", Toast.LENGTH_LONG ).show();

            }
        });

        //두번째 토스트 만들기.
        final Button toast2 = findViewById(R.id.toast2);

        toast2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getApplicationContext(),"내가 바로 토스트2예요...", Toast.LENGTH_SHORT).show();

            }
        });



        //1. 레이아웃 중에서 내가 처리하고 싶은 View를 찾아서 선택

        Button tel = findViewById(R.id.tel);

        //2. View를 어떻게 처리할지 코딩
        tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"전화걸기 화면으로 넘어갑니다.", Toast.LENGTH_SHORT).show();

                //화면전환 기능을 복사해서 가져온다.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-123-1234"));
                startActivity(intent); //위에서 셋팅한 intent 변수를 사용한다.
            }
        });





        // 브라우저를 띄우기.
        //1. 레이아웃 중에서 내가 처리하고 싶은 View를 찾아서 선택
        Button find = findViewById(R.id.find);
        //2. View를 어떻게 처리할지 코딩
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"검색 화면으로 넘어갑니다.", Toast.LENGTH_SHORT).show();

                //화면전환 기능을 복사해서 가져온다.
                Intent find = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
                startActivity(find); //위에서 셋팅한 intent 변수를 사용한다.
            }
        });


        // 로그인화면으로 전환하기
        //1. 레이아웃 중에서 내가 처리하고 싶은 View를 찾아서 선택
        Button login = findViewById(R.id.login);
        //2. View를 어떻게 처리할지 코딩
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"로그인 화면으로 넘어갑니다.", Toast.LENGTH_SHORT).show();
                // 전환하는 화면이 휴대폰의 기본기능이 아니므로 ACTION_VIEW, Uri.parse를 사용할 수 없다.
                // 자바는 class여야지만 실행된다.
                // getApplicationContext() : 지금 액티비티를 찾아라.
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class); //로그인액티비티의 설정값은 intent()안에 넣어준다.
                startActivity(intent); //위에서 셋팅한 intent 변수를 사용한다.
            }
        });

        // 내가 만든 로그인화면으로 전환하기
        //1. 레이아웃 중에서 내가 처리하고 싶은 View를 찾아서 선택
        Button myLogin = findViewById(R.id.myLogin);
        //2. View를 어떻게 처리할지 코딩
        myLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"내 로그인 화면으로 넘어갑니다.", Toast.LENGTH_SHORT).show();

                Intent intent2 = new Intent(getApplicationContext(), MyLoginActivity.class);
                startActivity(intent2); //위에서 셋팅한 intent2 변수를 사용한다.
            }
        });







    }

}
