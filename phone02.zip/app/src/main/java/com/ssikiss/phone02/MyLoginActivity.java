package com.ssikiss.phone02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

        EditText idText = findViewById(R.id.idText);
        EditText pwText = findViewById(R.id.pwText);
        // id, pw의 텍스트 필드 부분을 인식함.

        String id = idText.getText().toString(); //String으로 가지고 와라는 명령을 한번 더 넣어줌.
        String pw = pwText.getText().toString();

        String oriId = "root";
        String oriPW = "pass";

        //id 와 pw를 oriID와 oriPW와 비교함. &&(앤퍼센트)
        if(id.equals(oriId)&&pw.equals(oriPW)) {
            Toast.makeText(getApplicationContext(), "로그인 성공했습니다. 메모장으로 넘어갑니다.", Toast.LENGTH_SHORT).show();
            Intent ~


        }
         else {
            Toast.makeText(getApplicationContext(), "로그인 실패했습니다.", Toast.LENGTH_SHORT).show();
        }





















        Button login = findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MemoActivity.class);
                startActivity(intent);

            }
        });

    }
}
